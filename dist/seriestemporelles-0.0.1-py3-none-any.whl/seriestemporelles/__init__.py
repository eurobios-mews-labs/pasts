__version__ = '0.0.1'
#from seriestemporelles.signals.signal_abs import Signals
from seriestemporelles.signals.uniVariate import UniSignal
from seriestemporelles.signals.multiVariates import MultiSignal
