from seriestemporelles.signals.signal_abs import Signals
